from . import predict
import sys

def main():
    arg1 = sys.argv[1]
    predict.predict(arg1)
